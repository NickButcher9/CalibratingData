import os
from time import sleep
os.system("gpio mode 15 ALT0") # UART
os.system("gpio mode 16 ALT0") # UART


os.system("gpio mode 22 out") # GPIO 6
os.system("gpio mode 27 out") # GPIO 16

sleep(0.5)
os.system("gpio write 22 1")  # boot0 пин
sleep(0.5)
os.system("gpio write 27 0")  # ресетим
sleep(0.5)
os.system("gpio write 27 1")  # вырубаем ресет
sleep(0.5)

os.system("stm32flash -v -w 1.1.24.Zam.bin /dev/serial0")  # прошиваемс

sleep(0.5)
os.system("gpio write 22 0")  # boot0 возвращаем как было
sleep(0.5)
os.system("gpio write 27 0")  # ресетим
sleep(0.5)
os.system("gpio write 27 1")  # вырубаем ресет

os.system("gpio mode 22 in") # GPIO 6 убираем влияние распберри на стм
os.system("gpio mode 27 in") # GPIO 1os.system("gpio mode 15 ALT1") # UART

os.system("gpio mode 15 in") # UART
os.system("gpio mode 16 in") # UART


